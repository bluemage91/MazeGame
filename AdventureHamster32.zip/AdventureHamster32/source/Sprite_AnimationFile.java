import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Sprite_AnimationFile extends PApplet {

//Project By Chris Wilson, Jessica Young, Christopher Kim, and Robert Hodgson
//Citations:
//WASD image from istockphoto.com
//Game Music from freemusicarchive.org
//Lock Open Sound from freesound.org
//Key Sound from freesound.org

//Sound File Imports and Initialization

SoundFile keysoft;
SoundFile keymedium;
SoundFile keyloud;
SoundFile doornoise;
SoundFile music;

//Initialization of proper global variables
PImage playerImages []; //animation images
PImage player; //player image
PImage map; //map image
PImage fog; //fog of war
PImage startScreen; //starting screen
PImage wallMap; //map of the walls to handle collisions
PImage victory; //victory screen
PImage loss; //defeat screen
int playerFrames; //current frame of character animation
int countdown = millis();
int frameCnt=1; //frame count in the program
PFont myFont; //new font
boolean defeat = false;
boolean moving = false;
int animation = 0;
int animationCounter = 0;
int direction = 0;
boolean clipped = false;
int startTime = millis();
int currentTime = 0;
boolean start = true;

//Directional Determination
public void keyPressed() {
  
  //Directional Definers
  switch(key) {
  case 'w':
    direction = 1;
    break;
  case 's':
    direction = 2;
    break;
  case 'a':
    direction = 3;
    break;
  case 'd':
    direction = 4;
    break;
  default:
    direction = 0;
    break;
  }
  
  //Defines what to do when the spacebar is pressed
  if (key== ' ')
  {
  music.stop();//Stops previous Music
  music.play(); //Starts the music
  start=!start; //flips the start
  if (door.keyMet == true)
  {
    door.keyMet = false;
    berry.tengo = false;
    doorplayed = false;
    keyplayed = false;
    one.p_x=255; 
    one.p_y=255;
    berry.p_x = 1113; 
    berry.p_y = 403;
  }
  if (defeat == true)
  {
    defeat = false;
    berry.tengo = false;
    keyplayed = false;
    one.p_x=255; 
    one.p_y=255;
    berry.p_x = 1113; 
    berry.p_y = 403;
  }
  currentTime = 0;
  startTime = millis();
  }
}

public void keyReleased() {
  direction = 0;
}

//Defining the start Points
int[][] StartPointXY = {{815, 547}, 
  {255, 255}, 
  {965, 547}, 
  {1113, 403}};//array of starting points
int[][] doorLocal = {{1161, 692}, {38, 107}}; //array of starting point for the door

//Classes
class player
{
  int initialPlayer = PApplet.parseInt(random(0, 4));
  float p_x=StartPointXY[initialPlayer][0];
  float p_y=StartPointXY[initialPlayer][1];
  float v_x, v_y; //player velocity
  float a_x=0; 
  float a_y=0; //player acceleration
  PImage image; //image of the player
  int size = 35; //default size of player
}

class berryKey
{
  int initialKey = PApplet.parseInt(random(0, 4));
  float p_x=StartPointXY[initialKey][0];
  float p_y=StartPointXY[initialKey][1];
  boolean tengo=false; //start the game with the key unacquired
  PImage image; //image of key
  int size=25; //size of the key
}

class door
{
  int initialDoor = PApplet.parseInt(random(0, 2)); //0 or 1 value
  float p_x=doorLocal[initialDoor][0];
  float p_y=doorLocal[initialDoor][1];
  boolean keyMet = false; //key meets the door
  PImage image; //image of the door
  int size=85; //size of the door
}

//Creating the Objects
player one = new player();
berryKey berry = new berryKey();
door door = new door();

public boolean wallCheck() {
  boolean clear = false;

  return clear;
}


//Setup Function
public void setup()
{
  //Ensures Key & Player do not spawn at same point
  if (berry.initialKey == one.initialPlayer) {
    if (berry.initialKey == 3) { 
      berry.initialKey--;
      berry.p_x=StartPointXY[berry.initialKey][0];
      berry.p_y=StartPointXY[berry.initialKey][1];
    } else {
      berry.initialKey++;
      berry.p_x=StartPointXY[berry.initialKey][0];
      berry.p_y=StartPointXY[berry.initialKey][1];
    }
    berry.tengo=false;
    println("oops");
  }
  
  //Gives sound to sound variables
  keymedium = new SoundFile(this, "KeyMedium.wav");
  keyloud = new SoundFile(this, "KeyLoud.wav");
  doornoise = new SoundFile(this, "DoorOpen.wav");
  music = new SoundFile(this, "gamemusicV3.wav");
  
  //Attributing Images to PImage Variables
  map = loadImage("Maze SpriteV2.jpg"); //attributes map png to variable
  //map.re
  wallMap = loadImage("Maze Level E.jpg");
  wallMap.resize(1200, 800);
  fog = createImage(map.width, map.height, ARGB); //map sized blank image
  victory = loadImage("youwon.jpg"); //victory screen
  loss = loadImage("gameover.jpg"); //defeat screen
  startScreen = loadImage("startscreen.jpg"); //start screen
  one.image = loadImage("hamster.png");//loads hamster
  one.image.loadPixels();
  PImage tmp = createImage(one.image.width, one.image.height, ARGB);
  tmp.loadPixels();
  for ( int i = 0; i < one.image.width; i++ ) {
    for ( int j = 0; j < one.image.height; j++ ) {
      if (one.image.pixels[i + j*one.image.width] != color(255)) {
        tmp.pixels[i + j*one.image.width] = one.image.pixels[i + j*one.image.width]; //hamster remove white
      }
    }
  }
  one.image=tmp; //reset to have only the hamster
  one.image.updatePixels();
  berry.image = loadImage("key.png");//loads berry key
  berry.image.loadPixels();
  PImage tmp1 = createImage(berry.image.width, berry.image.height, ARGB);
  tmp.loadPixels();
  for ( int i = 0; i < berry.image.width; i++ ) {
    for ( int j = 0; j < berry.image.height; j++ ) {
      if (berry.image.pixels[i + j*berry.image.width] != color(255)) {
        tmp1.pixels[i + j*berry.image.width] = berry.image.pixels[i + j*berry.image.width];
      }
    }
  }
  berry.image=tmp1;
  berry.image.updatePixels();
  door.image = loadImage("door.png");
  //Writes door to the map
  map.loadPixels(); 
  door.image.resize(door.size, door.size);
  door.image.loadPixels();
  for ( int i = 0; i < door.image.width; i++ ) {
    for ( int j = 0; j < door.image.height; j++ ) {
      int doorSpot = (PApplet.parseInt(door.p_x)-door.size/2+i)
        + (PApplet.parseInt(door.p_y)-door.size/2 + j)*map.width;
      if (door.image.pixels[i + j*door.image.width] != color(255)) {
        map.pixels[doorSpot] = door.image.pixels[i + j*door.image.width];
      }
    }
  }
  map.updatePixels();

  //creating the animation
  playerFrames = 3;
  playerImages = new PImage[playerFrames];
  for (int i = 0; i<playerFrames; i++)
  {
    playerImages[i]=loadImage("roll"+i+".png");
    playerImages[i].loadPixels();
    PImage tmp3 = createImage(playerImages[i].width, playerImages[i].height, ARGB);
    tmp3.loadPixels();
    for ( int k = 0; k < playerImages[i].width; k++ ) {
      for ( int j = 0; j < playerImages[i].height; j++ ) {
        if (playerImages[i].pixels[k + j*playerImages[i].width] != color(255)) {
          tmp3.pixels[k + j*playerImages[i].width] = playerImages[i].pixels[k + j*playerImages[i].width]; //hamster remove white
        }
      }
    }
    tmp3.updatePixels();
    playerImages[i]=tmp3; //reset to have only the hamster
    playerImages[i].updatePixels();
  }

  size(1200, 800); //window creation
  background(255); //background creation
  myFont = createFont("PressStart2P.ttf", 128);//creation of font
}

//Removes the ability to see the full map as the player
public void fogOfWar(int xpos, int ypos, int size)
{
  //Creates the circle around the character
  map.loadPixels();
  fog.loadPixels();
  for (int i=0; i<map.width; i++)
  {
    for (int j=0; j<map.height; j++)
    {
      int index = i + j*map.width;
      int halfSize = PApplet.parseInt(size/2);
      if (i<=xpos+halfSize && i>=xpos-halfSize && j<=ypos+halfSize && j>=ypos-halfSize)
      {
        fog.pixels[index]=map.pixels[index]; //rewrites within the fog the original map
      } else
      {
        fog.pixels[index]=color(0, 0, 0); //everywhere else is black
      }
    }
  }
  fog.updatePixels();
}

//Defines the Frames where the Player Checkpoints Occur
int framekeyget = 0;
int framewon = 0;

//Draw Function
public void draw() {

  //Background and Fog of War
  imageMode(CORNER); //places the fog in the corner
  //image(map,0,0); //for debug
  int fowSize = 125;
  fogOfWar(PApplet.parseInt(one.p_x), PApplet.parseInt(one.p_y), fowSize); //lays down the fog of war
  image(fog, 0, 0);//places the fog on the drawing
  frameCnt++;
  
  //Countdown Timer
  currentTime = millis() - startTime;
  int Seconds = 60-((currentTime)/1000)%60;//presents the seconds
  int Minutes = 1-((currentTime)/(1000*60)) % 60; //represents the amount of minutes remaining
  textFont(myFont, 30);
  fill(255);
  //change position to wherever and presents the time
  text(nf(Minutes, 2) + ":" + nf(Seconds, 2), 550, 50);

  //GameOver Timing
  if (currentTime/1000==120)
  {
    defeat=true; //means player lost
  }

  //Sprite Portions
  imageMode(CENTER); //sprites are presented at center
  one.v_y=3; 
  one.v_x=3; //speed of player

  //Movement
  if (animationCounter < 3) {
    animation = 0;
  } else if (animationCounter < 6) {
    animation = 1;
  } else {
    animation = 2;
  }
  if (direction != 0 ) {//animates the sprite
    int charX = PApplet.parseInt(one.p_x) - one.size/2;
    int charY = PApplet.parseInt(one.p_y) - one.size/2;

    pushMatrix();
    translate(one.p_x, one.p_y);

    if (direction == 1) {
      for (int i = 0; i < one.size; i++) {
        int posCheck = (charX + i) + ((charY - 1)*map.width);
        if (wallMap.pixels[posCheck] != color(255)) {
          one.v_y=0;
          one.v_x=0;
        }
      }
      rotate(radians(180));
      image(playerImages[animation], 0, 0, one.size, one.size);
      one.p_y=one.p_y-one.v_y;//up
    } else if (direction == 2) {
      for (int i = 0; i < one.size; i++) {
        int posCheck = (charX + i) + ((charY + one.size + 1)*map.width);
        if (wallMap.pixels[posCheck] != color(255)) {
          one.v_y=0;
          one.v_x=0;
        }
      }
      image(playerImages[animation], 0, 0, one.size, one.size);
      one.p_y=one.v_y+one.p_y;//down
    } else if (direction == 3) {
      for (int i = 0; i < one.size; i++) {
        int posCheck = (charX - 1) + ((charY + i)*map.width);
        if (wallMap.pixels[posCheck] != color(255)) {
          one.v_y=0;
          one.v_x=0;
        }
      }
      rotate(radians(270));
      image(playerImages[animation], 0, 0, one.size, one.size);
      one.p_x=one.p_x-one.v_x;//left
    } else if (direction == 4) {
      for (int i = 0; i < one.size; i++) {
        int posCheck = (charX + one.size + 1) + ((charY + i)*map.width);
        if (wallMap.pixels[posCheck] != color(255)) {
          one.v_y=0;
          one.v_x=0;
        }
      }
      rotate(radians(90));
      image(playerImages[animation], 0, 0, one.size, one.size);
      one.p_x=one.p_x+one.v_x;//right
    }
    moving = true;
    popMatrix();
    animationCounter++;
  }
  if (!moving) {
    image(one.image, one.p_x, one.p_y, one.size, one.size);//normal player deposited
  }
  moving = false;
  imageMode(CORNER); //ask Chris about this
  if (animationCounter >= 9) {
    animationCounter = 0;
  }
  
  imageMode(CENTER); //Resets the image mode to center
  //If their field of vision enters the berrys region
  if (one.p_x+fowSize/2>berry.p_x && one.p_x-fowSize/2<berry.p_x &&
    one.p_y+fowSize/2>berry.p_y && one.p_y-fowSize/2<berry.p_y &&
    berry.tengo ==false)
  {
    image(berry.image, berry.p_x, berry.p_y, berry.size, berry.size); //berry placed
  }
  //if the player retreives the berry
  if (one.p_x+berry.size/2>berry.p_x && one.p_x-berry.size/2<berry.p_x &&
    one.p_y+berry.size/2>berry.p_y && one.p_y-berry.size/2<berry.p_y)
  {
    berry.tengo=true; //berry acquired
    framekeyget = frameCnt; //makes the frames the same
  }
  
  if (berry.tengo==true)
  {
    image(berry.image, 1100, 60, 60, 60); //Berry TR Place
    if (one.p_x+door.size/2>door.p_x && one.p_x-berry.size/2<door.p_x &&
      one.p_y+door.size/2>door.p_y && one.p_y-door.size/2<door.p_y)
    {
      door.keyMet = true;
    }
  }
  if (door.keyMet == true)
  {
    imageMode(CORNER);
    image(victory, 0, 0); //victory screen
    imageMode(CENTER);
    framewon = frameCnt; //sets the frame to a frame of victory
    music.stop(); //stops playing infinitely
  }

  //Game Over Screen
  if (defeat==true && door.keyMet==false)
  {
    imageMode(CORNER);
    image(loss, 0, 0); //Game OVer Screen Displayed
    imageMode(CENTER);
    music.stop();
  }
  
  //Start Screen
  if (start==true)
  {
    imageMode(CORNER);
    image(startScreen, 0, 0);//Start Screen Displayed
    imageMode(CENTER);
    one.p_x=StartPointXY[one.initialPlayer][0];
    one.p_y=StartPointXY[one.initialPlayer][1];
    berry.p_x=StartPointXY[berry.initialKey][0];
    berry.p_y=StartPointXY[berry.initialKey][1];
    berry.tengo = false;
    music.stop();
  }

  //In case the player leaves map
  if (one.p_x>1200 || one.p_x<0 || one.p_y<0 || one.p_y>900)
  {
    one.p_x = StartPointXY[one.initialPlayer][0]; 
    one.p_y = StartPointXY[one.initialPlayer][1];//Spawns the character here if they manage to leave map
  }
  
  //Entrance of the Sound Functions
  DoorSound(); //plays for the door being touched
  KeyGet(); //plays when key is obtained
}

//Booleans that help accomplish sound component
boolean keyplayed = false;
boolean doorplayed = false;

public void DoorSound()
{

  if (frameCnt == framewon && doorplayed == false) {
    doornoise.play();
    doorplayed = true;
  }
}
public void KeyGet()
{
  if (frameCnt == framekeyget && keyplayed == false) {
    keymedium.play();
    keyplayed = true;
  }
}
  public void settings() {  size(1200, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Sprite_AnimationFile" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
